from django.apps import AppConfig


class CardmallapiConfig(AppConfig):
    name = 'CardMallApi'
