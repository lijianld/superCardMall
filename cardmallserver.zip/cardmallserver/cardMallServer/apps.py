from django.apps import AppConfig


class CardmallserverConfig(AppConfig):
    name = 'cardMallServer'
